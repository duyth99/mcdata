/**
 * 
 */
package mcdata.api.http;


/**
 * @author ThangDQ
 *
 */

public interface HTTPService {
	void startHTTPService() throws Exception;
	void stopHTTPService() throws Exception;
	
}