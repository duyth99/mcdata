/**
 * 
 */
package mcdata.api.httpcontroller;

import javax.ws.rs.core.Response;

/**
 * @author thang
 *
 */
public interface HTTPController {
	public Response ping();

	
}
