package mcdata.api.model;

public class Arpu {

	private String msisdn;
	private String service_provider;
	private String tkc_thoai;
	private String tkc_data;
	private String tkc_sms;
	private String tkc_vas;
	private String so_du_tkc_tt;
	private String goi_data;
	private String ll_thoai;
	private String ll_sms;
	private String ll_data;
	private String device_name;
	
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getService_provider() {
		return service_provider;
	}
	public void setService_provider(String service_provider) {
		this.service_provider = service_provider;
	}
	public String getTkc_thoai() {
		return tkc_thoai;
	}
	public void setTkc_thoai(String tkc_thoai) {
		this.tkc_thoai = tkc_thoai;
	}
	public String getTkc_data() {
		return tkc_data;
	}
	public void setTkc_data(String tkc_data) {
		this.tkc_data = tkc_data;
	}
	public String getTkc_sms() {
		return tkc_sms;
	}
	public void setTkc_sms(String tkc_sms) {
		this.tkc_sms = tkc_sms;
	}
	public String getTkc_vas() {
		return tkc_vas;
	}
	public void setTkc_vas(String tkc_vas) {
		this.tkc_vas = tkc_vas;
	}
	public String getSo_du_tkc_tt() {
		return so_du_tkc_tt;
	}
	public void setSo_du_tkc_tt(String so_du_tkc_tt) {
		this.so_du_tkc_tt = so_du_tkc_tt;
	}
	public String getGoi_data() {
		return goi_data;
	}
	public void setGoi_data(String goi_data) {
		this.goi_data = goi_data;
	}
	public String getLl_thoai() {
		return ll_thoai;
	}
	public void setLl_thoai(String ll_thoai) {
		this.ll_thoai = ll_thoai;
	}
	public String getLl_sms() {
		return ll_sms;
	}
	public void setLl_sms(String ll_sms) {
		this.ll_sms = ll_sms;
	}
	public String getLl_data() {
		return ll_data;
	}
	public void setLl_data(String ll_data) {
		this.ll_data = ll_data;
	}
	public String getDevice_name() {
		return device_name;
	}
	public void setDevice_name(String device_name) {
		this.device_name = device_name;
	}
}
