package mcdata.api.model;

public class BaseInfoResponse extends ResponseObject{
	
//	private List<BaseInfo> response_body;
//
//	public List<BaseInfo> getResponse_body() {
//		return response_body;
//	}
//
//	public void setResponse_body(List<BaseInfo> response_body) {
//		this.response_body = response_body;
//	}
}
