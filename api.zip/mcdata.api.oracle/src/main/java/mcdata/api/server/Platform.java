package mcdata.api.server;

/**
 * @author ThangDQ
 *
 */

public class Platform {

}
