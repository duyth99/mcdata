package mcdata.api.server.impl;
import mcdata.api.server.Application;

/**
 * @author ThangDQ
 *
 */

public class ApplicationImpl extends Application{
	
}
